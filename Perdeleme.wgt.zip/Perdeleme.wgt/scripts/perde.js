// Bu eklenti İdol Yazilim tarafından Çözüm dershaneleri siparişi üzerine 
//yapılmıştır, Ek bilgi için: www.idolyazilim.com
//10-12-2013

$(document).ready(function()
{
	var settedWidth = 400;
	var settedHeight = 100;
	
	//$('body').height($(window).height());
	//$('.textbox').css("margin-top", $('#ub-widget').height() / 2 - ($('.textbox').height()/2));
	var windowHeight = $(window).height();
	//var halfWindow99percent = (windowHeight * 99 / 100) / 2;
	//var bodyHeight = windowHeight - halfWindow99percent;
	
	$('body').height(windowHeight);
	
	$(window).resize(function(){
		$('body').height($(window).height());
	//	$('.textbox').css("margin-top", $('#ub-widget').height() / 2 - ($('.textbox').height()/2));	
	});
	
	$('.kapat').on("click", function() {		
		$(this).hide();
		$('.ac').show();		
		$('#ub-widget').animate({
			width: "24px",
			height: "24px"
		}, 1000, function() {
			
			if(window.sankore)
			{
				//$('#hWidth').val($('body').width());
				//$('#hHeight').val($('body').height());
				
				sankore.setPreference('Width',$('body').width());
				sankore.setPreference('Height', $('body').height());
				sankore.setPreference('State', 'closed');
				
				sankore.resize(40,40);								
			}
		});
		//$('.textbox').hide();
	});
	
	$('.ac').on("click", function() {
		$(this).hide();
		$('.kapat').show();			
		if(window.sankore)
		{
			settedWidth = parseInt(sankore.preference('Width', settedWidth));//$('#hWidth').val();
			settedHeight = parseInt(sankore.preference('Height', settedHeight)); //$('#hHeight').val();

			if(!settedWidth)
				settedWidth= 400;
			
			if(!settedHeight)
				settedHeight= 100;

			sankore.setPreference('State', 'open');			
			sankore.resize(settedWidth, settedHeight);
			
		}
		
		var strSettedWidth = '99%';
		var strSettedHeight = '99%';//$('body').height()+"px";
		
		$('#ub-widget').animate({
			width: strSettedWidth,
			height: strSettedHeight 
		},1000,function() { 
			//$('.textbox').show();		
		});		
		
	});
	
	//$('.textbox').keyup(function() {
	//		if(window.sankore){
	//			sankore.setPreference("data",$('.textbox').val());
	//		}
	//
	//	});
	
	
	
	if(window.sankore)
	{
		//initialize		
		
		//var text = sankore.preference('data', '');
		
		
		//if(text)
		//	$('.textbox').val(text);
				
		var state = sankore.preference('State','open');
		//sankore.setPreference('State_d', state);
		if(state && state == 'closed')
		{		
			var width = parseInt(sankore.preference('Width', settedWidth));
			var height = parseInt(sankore.preference('Height', settedHeight));
			
			if(width && height)
				sankore.resize(width, height);		
		}				
	}
	
});